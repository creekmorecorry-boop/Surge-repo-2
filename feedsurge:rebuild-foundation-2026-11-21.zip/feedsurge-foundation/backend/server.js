import 'dotenv/config';
import crypto from 'node:crypto';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { createClient } from '@supabase/supabase-js';
import { S3Client, PutObjectCommand, HeadObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

const app = express();
const PORT = Number(process.env.PORT || 3001);
const MAX_JSON_BYTES = '1mb';
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const VIDEO_TYPES = new Set(['video/mp4', 'video/webm', 'video/quicktime']);
const MAX_IMAGE_BYTES = 12 * 1024 * 1024;
const MAX_VIDEO_BYTES = 100 * 1024 * 1024;

const supabaseUrl = process.env.SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const db = supabaseUrl && serviceRoleKey
  ? createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false } })
  : null;

const moderatorIds = new Set((process.env.FEEDSURGE_MODERATOR_IDS || '').split(',').map(x => x.trim()).filter(Boolean));
const allowedOrigins = new Set((process.env.CORS_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean));

const r2Ready = Boolean(process.env.R2_ACCOUNT_ID && process.env.R2_ACCESS_KEY_ID && process.env.R2_SECRET_ACCESS_KEY && process.env.R2_BUCKET && process.env.R2_PUBLIC_URL);
const r2 = r2Ready ? new S3Client({
  region: 'auto',
  endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: { accessKeyId: process.env.R2_ACCESS_KEY_ID, secretAccessKey: process.env.R2_SECRET_ACCESS_KEY }
}) : null;

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.has(origin)) return callback(null, true);
    return callback(new Error('Origin is not allowed by FEEDSURGE.'));
  },
  methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: false,
  maxAge: 600
}));
app.use(express.json({ limit: MAX_JSON_BYTES, strict: true }));

const generalLimiter = rateLimit({ windowMs: 60_000, limit: 180, standardHeaders: 'draft-8', legacyHeaders: false });
const authLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 20, standardHeaders: 'draft-8', legacyHeaders: false });
const writeLimiter = rateLimit({ windowMs: 60_000, limit: 45, standardHeaders: 'draft-8', legacyHeaders: false });
app.use('/api', generalLimiter);

function fail(res, status, message, code) {
  return res.status(status).json({ ok: false, error: message, ...(code ? { code } : {}) });
}
function cleanText(value, max) {
  return String(value ?? '').trim().slice(0, max);
}
function isUuid(value) { return UUID_RE.test(String(value || '')); }
function getBearer(req) {
  const header = String(req.headers.authorization || '');
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match?.[1] || null;
}
async function authenticatedUser(req) {
  if (!db) return { user: null, unavailable: true };
  const token = getBearer(req);
  if (!token) return { user: null, unavailable: false };
  const { data, error } = await db.auth.getUser(token);
  if (error || !data?.user) return { user: null, unavailable: false };
  return { user: data.user, unavailable: false };
}
async function requireUser(req, res) {
  const result = await authenticatedUser(req);
  if (result.unavailable) { fail(res, 503, 'Authentication service is not configured.'); return null; }
  if (!result.user) { fail(res, 401, 'A valid sign-in is required.'); return null; }
  return result.user;
}
function requireDatabase(res) {
  if (db) return true;
  fail(res, 503, 'Database service is not configured.');
  return false;
}
function mapSupabaseError(error, fallback) {
  // Do not expose SQL, table internals, credentials, or provider stack traces.
  const code = String(error?.code || '');
  if (code === '23505') return { status: 409, message: 'That action has already been recorded.' };
  if (code === '23503' || code === 'PGRST116') return { status: 404, message: 'The requested item was not found.' };
  return { status: 503, message: fallback };
}

app.get('/health', (_req, res) => res.json({ ok: true, service: 'FEEDSURGE API', status: 'healthy', configured: { database: Boolean(db), mediaStorage: Boolean(r2) } }));
app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'FEEDSURGE API', status: 'healthy' }));

// Supabase Auth is the source of truth for credentials and sessions.
app.post('/api/auth/register', authLimiter, async (req, res) => {
  if (!requireDatabase(res)) return;
  const email = cleanText(req.body?.email, 254).toLowerCase();
  const password = String(req.body?.password || '');
  const username = cleanText(req.body?.username, 24);
  if (!/^\S+@\S+\.\S+$/.test(email)) return fail(res, 400, 'Enter a valid email address.');
  if (password.length < 10 || password.length > 128) return fail(res, 400, 'Password must be between 10 and 128 characters.');
  if (!/^[a-zA-Z0-9_.]{3,24}$/.test(username)) return fail(res, 400, 'Username must be 3–24 characters using letters, numbers, underscores, or periods.');
  try {
    const { data, error } = await db.auth.signUp({ email, password, options: { data: { username, display_name: username } } });
    if (error) return fail(res, 400, error.message || 'Account registration could not be completed.');
    return res.status(201).json({ ok: true, user: data.user, session: data.session, requires_email_confirmation: Boolean(data.user && !data.session) });
  } catch { return fail(res, 503, 'Account registration is temporarily unavailable.'); }
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  if (!requireDatabase(res)) return;
  const email = cleanText(req.body?.email, 254).toLowerCase();
  const password = String(req.body?.password || '');
  if (!email || !password) return fail(res, 400, 'Email and password are required.');
  try {
    const { data, error } = await db.auth.signInWithPassword({ email, password });
    if (error || !data.session) return fail(res, 401, 'Email or password is incorrect.');
    return res.json({ ok: true, user: data.user, session: data.session, access_token: data.session.access_token });
  } catch { return fail(res, 503, 'Sign-in is temporarily unavailable.'); }
});

app.post('/api/auth/forgot-password', authLimiter, async (req, res) => {
  if (!requireDatabase(res)) return;
  const email = cleanText(req.body?.email, 254).toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email)) return fail(res, 400, 'Enter a valid email address.');
  try {
    const { error } = await db.auth.resetPasswordForEmail(email);
    if (error) return fail(res, 400, 'Password reset could not be started.');
    return res.json({ ok: true, message: 'If an account exists for that address, password reset instructions will be sent.' });
  } catch { return fail(res, 503, 'Password reset is temporarily unavailable.'); }
});

app.post('/api/auth/logout', async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  // Supabase access tokens are stateless from this API's perspective. The client must clear
  // its local session; server-side refresh-token revocation is handled by Supabase Auth.
  return res.json({ ok: true, user_id: user.id });
});

app.get('/api/me', async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  return res.json({ ok: true, user: { id: user.id, email: user.email, user_metadata: user.user_metadata || {} } });
});

app.get('/api/me/profile', async (req, res) => {
  const user = await requireUser(req, res);
  if (!user || !requireDatabase(res)) return;
  try {
    const { data, error } = await db.from('profiles').select('id,avatar_url').eq('id', user.id).maybeSingle();
    if (error) throw error;
    return res.json({ ok: true, profile: data || { id: user.id, avatar_url: null } });
  } catch (error) {
    const mapped = mapSupabaseError(error, 'Profile data is not ready. Confirm the existing profiles table and avatar_url column.');
    return fail(res, mapped.status, mapped.message);
  }
});

app.get('/api/media', async (req, res) => {
  if (!requireDatabase(res)) return;
  const limit = Math.min(50, Math.max(1, Number.parseInt(req.query.limit, 10) || 20));
  const cursor = req.query.before ? String(req.query.before) : null;
  if (cursor && Number.isNaN(Date.parse(cursor))) return fail(res, 400, 'Invalid feed cursor.');
  try {
    let query = db.from('surge_media')
      .select('id,user_id,public_url,media_type,title,description,created_at,status')
      .eq('status', 'published').order('created_at', { ascending: false }).limit(limit);
    if (cursor) query = query.lt('created_at', cursor);
    const { data, error } = await query;
    if (error) throw error;
    const media = data || [];
    const userIds = [...new Set(media.map(row => row.user_id).filter(Boolean))];
    let profiles = {};
    if (userIds.length) {
      const authors = await db.from('profiles').select('id,avatar_url').in('id', userIds);
      if (!authors.error) profiles = Object.fromEntries((authors.data || []).map(row => [row.id, row]));
    }
    return res.json({ ok: true, media: media.map(row => ({ ...row, author: profiles[row.user_id] || { id: row.user_id, avatar_url: null } })), next_cursor: media.at(-1)?.created_at || null });
  } catch (error) {
    const mapped = mapSupabaseError(error, 'The Arena feed is not available until its database schema is verified.');
    return fail(res, mapped.status, mapped.message);
  }
});

app.get('/api/users/:id/profile', async (req, res) => {
  const creatorId = String(req.params.id || '');
  if (!isUuid(creatorId)) return fail(res, 400, 'Invalid creator id.');
  if (!requireDatabase(res)) return;
  const viewer = await authenticatedUser(req);
  if (viewer.unavailable) return fail(res, 503, 'Authentication service is not configured.');
  try {
    const profile = await db.from('profiles').select('id,avatar_url').eq('id', creatorId).maybeSingle();
    if (profile.error) throw profile.error;
    if (!profile.data) return fail(res, 404, 'Creator not found.');
    const [posts, followers, following, followState] = await Promise.all([
      db.from('surge_media').select('id', { count: 'exact', head: true }).eq('user_id', creatorId).eq('status', 'published'),
      db.from('surge_follows').select('follower_id', { count: 'exact', head: true }).eq('followed_id', creatorId),
      db.from('surge_follows').select('followed_id', { count: 'exact', head: true }).eq('follower_id', creatorId),
      viewer.user && viewer.user.id !== creatorId ? db.from('surge_follows').select('follower_id').eq('follower_id', viewer.user.id).eq('followed_id', creatorId).maybeSingle() : Promise.resolve({ data: null, error: null })
    ]);
    for (const result of [posts, followers, following, followState]) if (result.error) throw result.error;
    return res.json({ ok: true, profile: { ...profile.data, posts: posts.count || 0, followers: followers.count || 0, following: following.count || 0, is_following: Boolean(followState.data), is_self: viewer.user?.id === creatorId } });
  } catch (error) {
    const mapped = mapSupabaseError(error, 'Creator profile could not be loaded.');
    return fail(res, mapped.status, mapped.message);
  }
});

app.post('/api/media/:id/like', writeLimiter, async (req, res) => {
  const user = await requireUser(req, res);
  if (!user || !requireDatabase(res)) return;
  const mediaId = String(req.params.id || '');
  if (!isUuid(mediaId)) return fail(res, 400, 'Invalid media id.');
  try {
    const existing = await db.from('surge_media_likes').select('media_id').eq('media_id', mediaId).eq('user_id', user.id).maybeSingle();
    if (existing.error) throw existing.error;
    if (existing.data) {
      const removed = await db.from('surge_media_likes').delete().eq('media_id', mediaId).eq('user_id', user.id);
      if (removed.error) throw removed.error;
    } else {
      const added = await db.from('surge_media_likes').insert({ media_id: mediaId, user_id: user.id });
      if (added.error) throw added.error;
    }
    const count = await db.from('surge_media_likes').select('media_id', { count: 'exact', head: true }).eq('media_id', mediaId);
    if (count.error) throw count.error;
    return res.json({ ok: true, liked: !existing.data, count: count.count || 0 });
  } catch (error) {
    const mapped = mapSupabaseError(error, 'Like could not be saved.');
    return fail(res, mapped.status, mapped.message);
  }
});

app.get('/api/media/:id/comments', async (req, res) => {
  if (!requireDatabase(res)) return;
  const mediaId = String(req.params.id || '');
  if (!isUuid(mediaId)) return fail(res, 400, 'Invalid media id.');
  try {
    const { data, error } = await db.from('surge_media_comments').select('id,media_id,user_id,body,created_at').eq('media_id', mediaId).eq('status', 'visible').order('created_at', { ascending: true }).limit(100);
    if (error) throw error;
    return res.json({ ok: true, comments: data || [] });
  } catch (error) {
    const mapped = mapSupabaseError(error, 'Comments could not be loaded.');
    return fail(res, mapped.status, mapped.message);
  }
});

app.post('/api/media/:id/comments', writeLimiter, async (req, res) => {
  const user = await requireUser(req, res);
  if (!user || !requireDatabase(res)) return;
  const mediaId = String(req.params.id || '');
  const body = cleanText(req.body?.body, 1000);
  if (!isUuid(mediaId)) return fail(res, 400, 'Invalid media id.');
  if (!body) return fail(res, 400, 'Comment cannot be empty.');
  try {
    const { data, error } = await db.from('surge_media_comments').insert({ media_id: mediaId, user_id: user.id, body }).select('id,media_id,user_id,body,created_at').single();
    if (error) throw error;
    return res.status(201).json({ ok: true, comment: data });
  } catch (error) {
    const mapped = mapSupabaseError(error, 'Comment could not be saved.');
    return fail(res, mapped.status, mapped.message);
  }
});

app.post('/api/users/:id/follow', writeLimiter, async (req, res) => {
  const user = await requireUser(req, res);
  if (!user || !requireDatabase(res)) return;
  const targetId = String(req.params.id || '');
  if (!isUuid(targetId) || targetId === user.id) return fail(res, 400, 'Invalid creator.');
  try {
    const existing = await db.from('surge_follows').select('follower_id').eq('follower_id', user.id).eq('followed_id', targetId).maybeSingle();
    if (existing.error) throw existing.error;
    if (existing.data) {
      const { error } = await db.from('surge_follows').delete().eq('follower_id', user.id).eq('followed_id', targetId);
      if (error) throw error;
    } else {
      const { error } = await db.from('surge_follows').insert({ follower_id: user.id, followed_id: targetId });
      if (error) throw error;
    }
    return res.json({ ok: true, following: !existing.data });
  } catch (error) {
    const mapped = mapSupabaseError(error, 'Follow could not be updated.');
    return fail(res, mapped.status, mapped.message);
  }
});

// Request a short-lived, user-scoped R2 upload URL. Upload finalization validates the object
// using HEAD before creating the durable media row. Stories are intentionally not handled here.
app.post('/api/media/upload-url', writeLimiter, async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  if (!r2 || !db) return fail(res, 503, 'Media storage is not configured.');
  const contentType = cleanText(req.body?.content_type, 100).toLowerCase();
  const size = Number(req.body?.size_bytes);
  const mode = req.body?.mode === 'avatar' ? 'avatar' : 'post';
  const allowed = mode === 'avatar' ? IMAGE_TYPES.has(contentType) : IMAGE_TYPES.has(contentType) || VIDEO_TYPES.has(contentType);
  if (!allowed) return fail(res, 400, 'This media type is not supported.');
  const maxSize = contentType.startsWith('image/') ? (mode === 'avatar' ? 8 : MAX_IMAGE_BYTES) : MAX_VIDEO_BYTES;
  if (!Number.isSafeInteger(size) || size < 1 || size > maxSize) return fail(res, 413, 'File size is outside the allowed limit.');
  const ext = ({ 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov' })[contentType];
  const prefix = mode === 'avatar' ? 'avatars' : 'surges';
  const key = `${prefix}/${user.id}/${Date.now()}-${crypto.randomUUID()}.${ext}`;
  try {
    const command = new PutObjectCommand({ Bucket: process.env.R2_BUCKET, Key: key, ContentType: contentType });
    const uploadUrl = await getSignedUrl(r2, command, { expiresIn: 300 });
    return res.json({ ok: true, upload_url: uploadUrl, key, method: 'PUT', expires_in: 300, required_headers: { 'Content-Type': contentType }, mode });
  } catch { return fail(res, 503, 'A secure upload URL could not be created.'); }
});

app.post('/api/media/complete', writeLimiter, async (req, res) => {
  const user = await requireUser(req, res);
  if (!user || !requireDatabase(res)) return;
  if (!r2) return fail(res, 503, 'Media storage is not configured.');
  const key = cleanText(req.body?.key, 500);
  const mode = req.body?.mode === 'avatar' ? 'avatar' : 'post';
  const title = cleanText(req.body?.title, 180);
  const description = cleanText(req.body?.description, 2000);
  const expectedPrefix = `${mode === 'avatar' ? 'avatars' : 'surges'}/${user.id}/`;
  if (!key.startsWith(expectedPrefix) || key.includes('..') || key.includes('\\')) return fail(res, 403, 'Upload does not belong to this account.');
  try {
    const head = await r2.send(new HeadObjectCommand({ Bucket: process.env.R2_BUCKET, Key: key }));
    const contentType = String(head.ContentType || '').toLowerCase();
    const size = Number(head.ContentLength || 0);
    const isImage = IMAGE_TYPES.has(contentType);
    const isVideo = VIDEO_TYPES.has(contentType);
    if (mode === 'avatar' && !isImage) return fail(res, 400, 'Profile images must be JPEG, PNG, or WebP.');
    if (mode === 'post' && !isImage && !isVideo) return fail(res, 400, 'Uploaded media type is not supported.');
    const maxSize = isImage ? (mode === 'avatar' ? 8 * 1024 * 1024 : MAX_IMAGE_BYTES) : MAX_VIDEO_BYTES;
    if (!size || size > maxSize) return fail(res, 413, 'Uploaded file size is invalid.');
    const publicUrl = `${String(process.env.R2_PUBLIC_URL).replace(/\/$/, '')}/${key}`;
    if (mode === 'avatar') {
      const { data, error } = await db.from('profiles').upsert({ id: user.id, avatar_url: publicUrl }, { onConflict: 'id' }).select('id,avatar_url').single();
      if (error) throw error;
      return res.json({ ok: true, mode, profile: data, key });
    }
    const { data, error } = await db.from('surge_media').insert({ user_id: user.id, object_key: key, public_url: publicUrl, media_type: isImage ? 'photo' : 'video', content_type: contentType, size_bytes: size, title: title || null, description: description || null, status: 'published' }).select('id,user_id,object_key,public_url,media_type,title,description,created_at,status').single();
    if (error) throw error;
    return res.status(201).json({ ok: true, mode, media: data });
  } catch (error) {
    if (error?.name === 'NotFound' || error?.$metadata?.httpStatusCode === 404) return fail(res, 400, 'Uploaded file was not found. Try again.');
    const mapped = mapSupabaseError(error, 'Media could not be finalized. Verify the existing media schema and storage configuration.');
    return fail(res, mapped.status, mapped.message);
  }
});

app.post('/api/reports', writeLimiter, async (req, res) => {
  const user = await requireUser(req, res);
  if (!user || !requireDatabase(res)) return;
  const mediaId = req.body?.media_id ? String(req.body.media_id) : null;
  const reportedUserId = req.body?.reported_user_id ? String(req.body.reported_user_id) : null;
  const reason = cleanText(req.body?.reason, 20).toLowerCase();
  const detail = cleanText(req.body?.detail, 2000);
  if ((!mediaId && !reportedUserId) || (mediaId && !isUuid(mediaId)) || (reportedUserId && !isUuid(reportedUserId))) return fail(res, 400, 'Choose a valid post or account to report.');
  if (!['spam', 'abuse', 'copyright', 'other'].includes(reason)) return fail(res, 400, 'Choose a valid report reason.');
  try {
    const { data, error } = await db.from('surge_reports').insert({ reporter_id: user.id, media_id: mediaId, reported_user_id: reportedUserId, reason, detail: detail || null }).select('id,status,created_at').single();
    if (error) throw error;
    return res.status(201).json({ ok: true, report: data });
  } catch (error) {
    const mapped = mapSupabaseError(error, 'Report could not be submitted.');
    return fail(res, mapped.status, mapped.message);
  }
});

app.get('/api/moderation/reports', async (req, res) => {
  const user = await requireUser(req, res);
  if (!user || !requireDatabase(res)) return;
  if (!moderatorIds.size || !moderatorIds.has(user.id)) return fail(res, moderatorIds.size ? 403 : 503, moderatorIds.size ? 'Moderator access required.' : 'Moderation is not configured.');
  const status = cleanText(req.query.status || 'open', 20);
  if (!['open', 'reviewing', 'resolved', 'dismissed', 'all'].includes(status)) return fail(res, 400, 'Invalid report status.');
  try {
    let query = db.from('surge_reports').select('*').order('created_at', { ascending: true }).limit(100);
    if (status !== 'all') query = query.eq('status', status);
    const { data, error } = await query;
    if (error) throw error;
    return res.json({ ok: true, reports: data || [] });
  } catch (error) {
    const mapped = mapSupabaseError(error, 'Moderation queue could not be loaded.');
    return fail(res, mapped.status, mapped.message);
  }
});

app.patch('/api/moderation/reports/:id/status', writeLimiter, async (req, res) => {
  const user = await requireUser(req, res);
  if (!user || !requireDatabase(res)) return;
  if (!moderatorIds.size || !moderatorIds.has(user.id)) return fail(res, moderatorIds.size ? 403 : 503, 'Moderator access required.');
  const reportId = String(req.params.id || '');
  const status = cleanText(req.body?.status, 20);
  if (!isUuid(reportId) || !['reviewing', 'resolved', 'dismissed'].includes(status)) return fail(res, 400, 'Invalid moderation update.');
  try {
    const { data, error } = await db.from('surge_reports').update({ status }).eq('id', reportId).select('id,status').single();
    if (error) throw error;
    return res.json({ ok: true, report: data });
  } catch (error) {
    const mapped = mapSupabaseError(error, 'Report status could not be updated.');
    return fail(res, mapped.status, mapped.message);
  }
});

app.use('/api', (_req, res) => fail(res, 404, 'API route not found.'));
app.use((error, _req, res, _next) => {
  if (error?.message === 'Origin is not allowed by FEEDSURGE.') return fail(res, 403, error.message);
  if (error instanceof SyntaxError && 'body' in error) return fail(res, 400, 'Request body must be valid JSON.');
  console.error('[FEEDSURGE API]', error?.message || 'Unhandled server error');
  return fail(res, 500, 'An unexpected server error occurred.');
});

app.listen(PORT, () => console.log(`FEEDSURGE API listening on port ${PORT}`));

# FEEDSURGE Foundation — Stage 1

This is a **staged replacement foundation**, not a production cutover. It is intentionally delivered in a new folder so it does not overwrite the existing `backend/`, `index.html`, package manifests, or live Render configuration while the replacement is being validated.

## Contents

- `backend/server.js` — new Express API foundation using Supabase Auth, the existing `surge_media` / social table names, and optional Cloudflare R2 uploads.
- `backend/package.json` — one consistent ESM runtime and dependency set for this staged backend.
- `backend/.env.example` — variable names only; never put real credentials in GitHub.
- `docs/IMPLEMENTATION_STATUS.md` — what is implemented now and what is deliberately not yet implemented.

## Important before upload or deployment

1. Upload the `feedsurge-foundation` folder to the branch `feedsurge/rebuild-foundation-2026-11-21` at the repository root. Do not replace existing files yet.
2. Do not point Render at this folder yet. First confirm the existing service's root directory, start command, and staging environment.
3. Create a separate staging environment and use a staging Supabase project or isolated test data. Do not test destructive operations against production.
4. Copy values into the deployment environment's secret settings. Never commit `.env` or service-role keys.
5. The API depends on the existing additive migration's `surge_media`, `surge_media_likes`, `surge_media_comments`, `surge_follows`, `surge_reports`, and `profiles.avatar_url` schema. The migration has **not** been run by this package.
6. The current backend file in the branch is incomplete. This new server is independent of it, but it is not a drop-in production replacement until staging integration tests pass.

## Run locally

From `feedsurge-foundation/backend`:

```bash
npm install
cp .env.example .env
# Fill in staging credentials in .env
npm run check
npm start
```

The health endpoint is `GET /health`. Without Supabase configuration, it reports the API process as healthy and reports database/media storage as not configured. That is not a claim that the full platform is operational.

## Current API endpoints

- `GET /health`, `GET /api/health`
- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/forgot-password`, `POST /api/auth/logout`
- `GET /api/me`, `GET /api/me/profile`
- `GET /api/media`, `GET /api/users/:id/profile`
- `POST /api/media/:id/like`
- `GET /api/media/:id/comments`, `POST /api/media/:id/comments`
- `POST /api/users/:id/follow`
- `POST /api/media/upload-url`, `POST /api/media/complete`
- `POST /api/reports`
- `GET /api/moderation/reports`, `PATCH /api/moderation/reports/:id/status`

Stories, messaging, saves, notifications, search/recommendations, profile editing, and full membership/billing are not included in Stage 1. They remain required parts of the complete FEEDSURGE build and will be implemented in subsequent stages against a verified schema/API contract. Stories will be kept separate from Arena publishing.
